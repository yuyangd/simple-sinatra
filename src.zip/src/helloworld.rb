require 'sinatra'
get '/' do
  "Hello World From Rea!"
end
